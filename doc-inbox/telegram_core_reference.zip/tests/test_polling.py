"""Tests for offset durability and polling helpers."""

from pathlib import Path
from unittest.mock import patch

from telegram_core.polling import read_offset, write_offset


def test_write_and_read_offset(tmp_path: Path) -> None:
    offset_file = tmp_path / "subdir" / "offset.txt"
    assert read_offset(offset_file) is None

    write_offset(offset_file, 105)
    assert read_offset(offset_file) == 105

    write_offset(offset_file, 106)
    assert read_offset(offset_file) == 106


def test_read_offset_corrupted(tmp_path: Path) -> None:
    offset_file = tmp_path / "offset.txt"
    offset_file.write_text("corrupted_string_not_an_int", encoding="utf-8")
    assert read_offset(offset_file) is None


def test_read_offset_empty(tmp_path: Path) -> None:
    offset_file = tmp_path / "offset.txt"
    offset_file.write_text("   \n", encoding="utf-8")
    assert read_offset(offset_file) is None


def test_write_offset_suppresses_unlink_oserror(tmp_path: Path) -> None:
    """If os.replace fails and tmp_path.unlink also raises OSError, write_offset never raises."""
    offset_file = tmp_path / "offset.txt"
    with patch("os.replace", side_effect=OSError("disk failure")):
        with patch.object(Path, "unlink", side_effect=OSError("permission denied")):
            write_offset(offset_file, 42)


def test_send_reaction_catches_and_swallows_errors() -> None:
    import httpx
    from pydantic import SecretStr
    from telegram_core.client import TelegramClient
    from telegram_core.polling import send_reaction

    token = "fake_token_123"

    def failing_handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(400, json={"ok": False, "error_code": 400, "description": "Bad Request: message not found"})

    client = TelegramClient(SecretStr(token), transport=httpx.MockTransport(failing_handler))
    # Should not raise any exception despite 400 Bad Request
    send_reaction(client, chat_id=123, message_id=456, reaction="👍", token=token)
