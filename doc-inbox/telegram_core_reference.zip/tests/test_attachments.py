"""Tests for attachment handling, filename safety, and size guards."""

from typing import Any

import httpx
import pytest
from pydantic import SecretStr

from telegram_core.attachments import (
    _extract_source,
    _largest_photo_size,
    download_attachment,
    is_valid_file_name,
)
from telegram_core.client import TelegramClient

SECRET = SecretStr("123456789:AAFakeTokenForTelegramClientTests_x")


@pytest.mark.parametrize(
    "name",
    [
        "CON",
        "con",
        "con.txt",
        "PRN",
        "prn.pdf",
        "AUX",
        "aux.mp4",
        "NUL",
        "NUL.bin",
        "COM1",
        "com9.jpg",
        "LPT1",
        "lpt5.doc",
        "file/name.txt",
        "file\\name.txt",
        "file:name.txt",
        "file*name.txt",
        "file?name.txt",
        'file"name.txt',
        "file<name.txt",
        "file>name.txt",
        "file|name.txt",
        "trailing_dot.",
        "trailing_space ",
        "control_char\x00.txt",
        "control_char\x1f.txt",
        "newline\n.txt",
        "tab\t.txt",
        ".",
        "..",
        "",
        "a" * 256,  # 256 bytes > 255 limit
        "a" * 252 + ".txt",  # 256 bytes > 255 limit
        "тест" * 65,  # 260 UTF-8 bytes > 255 limit
        "\ud800.txt",  # lone surrogate
    ],
)
def test_invalid_filenames_rejected(name: str) -> None:
    assert not is_valid_file_name(name)


@pytest.mark.parametrize(
    "name",
    [
        "report.pdf",
        "photo_123.jpg",
        "my document (v2).docx",
        "COM10.txt",
        "CONSOLE.txt",
        "document.CON",
        "COM",
        "LPT",
        "a" * 255,  # exactly 255 bytes
        "тест_документ.pdf",
    ],
)
def test_valid_filenames_accepted(name: str) -> None:
    assert is_valid_file_name(name)


def test_largest_photo_size_selects_max_area() -> None:
    sizes: list[dict[str, Any]] = [
        {"file_id": "small", "width": 100, "height": 100, "file_size": 1000},
        {"file_id": "medium", "width": 300, "height": 200, "file_size": 4000},
        {"file_id": "largest", "width": 800, "height": 600, "file_size": 25000},
    ]
    assert _largest_photo_size(sizes)["file_id"] == "largest"


def test_precedence_live_photo_over_photo() -> None:
    message = {
        "live_photo": {"photo": [{"file_id": "live_id", "width": 100, "height": 100}]},
        "photo": [{"file_id": "photo_id", "width": 100, "height": 100}],
    }
    source = _extract_source("live_photo", message["live_photo"])
    assert source.type == "live_photo"
    assert source.file_id == "live_id"


def test_none_filesize_treated_as_limit_exceeded() -> None:
    """If Telegram does not confirm file_size after getFile, do not download."""
    def handler(request: httpx.Request) -> httpx.Response:
        if "/getFile" in str(request.url):
            return httpx.Response(
                200,
                json={"ok": True, "result": {"file_id": "doc1", "file_path": "docs/file.bin"}},
            )
        raise AssertionError("downloadFile must not be called when file_size is None")

    transport = httpx.MockTransport(handler)
    client = TelegramClient(SECRET, transport=transport)

    message = {"document": {"file_id": "doc1", "file_name": "file.bin"}}
    info = download_attachment(message, client, max_attachment_size_bytes=20_000_000)

    assert info is not None
    assert info.status == "skipped"
    assert info.error_reason == "size_limit_exceeded"
    assert info.content is None
