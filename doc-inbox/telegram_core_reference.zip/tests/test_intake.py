"""Tests for intake classification and authorization rules."""

from telegram_core.intake import Outcome, classify_update, select_message

ALLOWED = [12345]


def test_select_message() -> None:
    assert select_message({}) is None
    assert select_message({"message": {"id": 1}}) == {"id": 1}
    assert select_message({"edited_message": {"id": 2}}) == {"id": 2}


def test_unauthorized_sender_silently_ignored() -> None:
    update = {
        "update_id": 1,
        "message": {
            "message_id": 10,
            "chat": {"id": 999, "type": "private"},
            "from": {"id": 99999},  # not in ALLOWED
            "text": "Hello",
        },
    }
    res = classify_update(update, ALLOWED)
    assert res.outcome == Outcome.SILENT
    assert res.reaction is None


def test_non_private_chat_silently_ignored() -> None:
    update = {
        "update_id": 1,
        "message": {
            "message_id": 10,
            "chat": {"id": -100123456, "type": "supergroup"},
            "from": {"id": 12345},
            "text": "Hello",
        },
    }
    res = classify_update(update, ALLOWED)
    assert res.outcome == Outcome.SILENT


def test_negative_or_zero_message_id_silently_ignored() -> None:
    update = {
        "update_id": 1,
        "message": {
            "message_id": 0,
            "chat": {"id": 12345, "type": "private"},
            "from": {"id": 12345},
            "text": "Hello",
        },
    }
    assert classify_update(update, ALLOWED).outcome == Outcome.SILENT


def test_service_messages_silently_ignored() -> None:
    for field in [
        "pinned_message",
        "managed_bot_created",
        "poll_option_added",
        "poll_option_deleted",
    ]:
        update = {
            "update_id": 1,
            "message": {
                "message_id": 10,
                "chat": {"id": 12345, "type": "private"},
                "from": {"id": 12345},
                field: {"some": "data"},
            },
        }
        assert classify_update(update, ALLOWED).outcome == Outcome.SILENT


def test_unknown_forward_origin_type_produces_thinking_face() -> None:
    """Rule 5: forward_origin with an unknown type yields NO_BUNDLE and 🤔."""
    update = {
        "update_id": 1,
        "message": {
            "message_id": 10,
            "chat": {"id": 12345, "type": "private"},
            "from": {"id": 12345},
            "text": "Forwarded post",
            "forward_origin": {"type": "brand_new_telegram_forward_type", "date": 1234567890},
        },
    }
    res = classify_update(update, ALLOWED)
    assert res.outcome == Outcome.NO_BUNDLE
    assert res.reaction == "🤔"


def test_known_forward_origin_type_produces_bundle() -> None:
    for fwd_type in ["user", "hidden_user", "chat", "channel"]:
        update = {
            "update_id": 1,
            "message": {
                "message_id": 10,
                "chat": {"id": 12345, "type": "private"},
                "from": {"id": 12345},
                "text": "Forwarded post",
                "forward_origin": {"type": fwd_type, "date": 1234567890},
            },
        }
        res = classify_update(update, ALLOWED)
        assert res.outcome == Outcome.BUNDLE
        assert res.reaction == "👍"


def test_valid_payload_produces_bundle_and_thumbs_up() -> None:
    for field, val in [("text", "hello"), ("photo", []), ("document", {})]:
        update = {
            "update_id": 1,
            "message": {
                "message_id": 10,
                "chat": {"id": 12345, "type": "private"},
                "from": {"id": 12345},
                field: val,
            },
        }
        res = classify_update(update, ALLOWED)
        assert res.outcome == Outcome.BUNDLE
        assert res.reaction == "👍"


def test_unsupported_payload_produces_no_bundle_and_thumbs_down() -> None:
    update = {
        "update_id": 1,
        "message": {
            "message_id": 10,
            "chat": {"id": 12345, "type": "private"},
            "from": {"id": 12345},
            "sticker": {"file_id": "stk1"},
        },
    }
    res = classify_update(update, ALLOWED)
    assert res.outcome == Outcome.NO_BUNDLE
    assert res.reaction == "👎"


def test_unknown_field_produces_thinking_face() -> None:
    update = {
        "update_id": 1,
        "message": {
            "message_id": 10,
            "chat": {"id": 12345, "type": "private"},
            "from": {"id": 12345},
            "some_brand_new_telegram_feature_field": {"data": 123},
        },
    }
    res = classify_update(update, ALLOWED)
    assert res.outcome == Outcome.NO_BUNDLE
    assert res.reaction == "🤔"
