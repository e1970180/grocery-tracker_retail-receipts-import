# External API & Protocol Versions

## 1. External APIs

| API | Version | Release Date | Source / Specification | Key Constraints & Endpoints |
|---|---|---|---|---|
| **Telegram Bot API** | `10.3` | 2026-08-24 | [Telegram Bot API Docs](https://core.telegram.org/bots/api) | Long polling (`getUpdates`), `getFile` (Cloud Bot API limit: 20 MB), `downloadFile` (`/file/bot<token>/<path>`), `setMessageReaction(chat_id, message_id)`. |

## 2. Standards & Constraints

| Standard / Rule | Title / Description | Reference |
|---|---|---|
| **RFC 3339** | Timestamps in ISO-8601 / RFC 3339 format strictly in UTC with `Z` suffix. | [RFC 3339](https://www.rfc-editor.org/rfc/rfc3339.html) |
| **Cross-platform Filenames** | File names safe on Windows (no reserved device names, no trailing dot/space, no control chars), Linux, and macOS simultaneously. Max 255 UTF-8 bytes. | `docs/telegram_ingestion_spec.md` §3.3 |
