"""Telegram Core: standalone reference module for Telegram message ingestion.

Contains:
- Transport with retry and token redaction (TelegramClient)
- Intake classification and authorization (classify_update, select_message)
- Attachment download and sanitization (download_attachment)
- Durable polling loop with atomic offset tracking (run_polling_loop)
"""

from telegram_core.attachments import AttachmentInfo, download_attachment
from telegram_core.client import TelegramAPIError, TelegramClient, TelegramRetryExhaustedError
from telegram_core.intake import IntakeResult, Outcome, classify_update, select_message
from telegram_core.polling import run_polling_loop

__all__ = [
    "AttachmentInfo",
    "IntakeResult",
    "Outcome",
    "TelegramAPIError",
    "TelegramClient",
    "TelegramRetryExhaustedError",
    "classify_update",
    "download_attachment",
    "run_polling_loop",
    "select_message",
]
