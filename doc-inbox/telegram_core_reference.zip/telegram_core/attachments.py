"""Attachment extraction and download with security guards.

Key guarantees:
1. Field precedence: live_photo checked before photo, animation before document
   (Telegram Bot API sets both for backwards compatibility; checking photo/document
   first would permanently shadow the more specific type).
2. Photo resolution: PhotoSize array resolved to largest pixel area.
3. Cross-platform filename safety (Windows, Linux, macOS, iOS):
   - Rejects illegal characters: / \\ : * ? " < > |
   - Rejects ASCII control characters: 0x00–0x1F (invalid on Windows, \x00 invalid everywhere).
   - Rejects names exceeding 255 UTF-8 bytes (NAME_MAX on Linux ext4/APFS; within NTFS 255 UTF-16 units).
   - Rejects unencodable characters (lone surrogates).
   - Rejects Windows reserved device names (CON, PRN, AUX, NUL, COM1-9, LPT1-9)
     irrespective of extension (e.g. NUL.txt, CON.pdf).
   - Rejects trailing dots or spaces.
   - Falls back to deterministic template: {attachment_id}_{type}.{ext}.
4. Memory & size limits:
   - Checks size before getFile.
   - Re-checks size after getFile.
   - If getFile returns no confirmed file_size (file_size is None), it is
     treated as exceeding the limit to prevent unbounded memory downloads.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from telegram_core.client import (
    TelegramAPIError,
    TelegramClient,
    TelegramRetryExhaustedError,
)

# Order matters: live_photo before photo, animation before document.
ATTACHMENT_FIELDS = (
    "live_photo",
    "photo",
    "animation",
    "document",
    "video",
    "audio",
    "voice",
    "video_note",
)

_FALLBACK_EXT: dict[str, str] = {
    "photo": "jpg",
    "video": "mp4",
    "document": "bin",
    "audio": "mp3",
    "voice": "ogg",
    "video_note": "mp4",
    "animation": "mp4",
    "live_photo": "jpg",
}

_UNSAFE_FILE_NAME_CHARS = frozenset('/\\:*?"<>|')

_RESERVED_DEVICE_NAMES = frozenset(
    {"CON", "PRN", "AUX", "NUL"}
    | {f"COM{digit}" for digit in "123456789"}
    | {f"LPT{digit}" for digit in "123456789"}
)

_MAX_FILE_NAME_BYTES = 255


class NoSizeVariantError(Exception):
    """The attachment's PhotoSize array is empty or absent."""


@dataclass(frozen=True, slots=True)
class _Source:
    """One attachment's raw Telegram data resolved to a single downloadable file."""

    type: str
    file_id: str
    file_size: int | None
    source_file_name: str | None
    mime_type: str | None
    width: int | None
    height: int | None
    duration_sec: float | None
    performer: str | None
    title: str | None


@dataclass(frozen=True, slots=True)
class AttachmentInfo:
    """Result of an attachment download attempt."""

    attachment_id: int
    type: str
    file_name: str | None
    status: str  # "downloaded" | "skipped"
    error_reason: str | None  # "size_limit_exceeded" | "unavailable_in_source" | "download_error" | None
    content: bytes | None
    size_bytes: int | None
    mime_type: str | None
    width: int | None = None
    height: int | None = None
    duration_sec: float | None = None


def _largest_photo_size(sizes: list[dict[str, Any]]) -> dict[str, Any]:
    """Select the PhotoSize with greatest pixel area, tie-broken by file_size."""
    if not sizes:
        raise NoSizeVariantError("Empty photo size array")
    return max(
        sizes,
        key=lambda s: (s.get("width", 0) * s.get("height", 0), s.get("file_size", 0)),
    )


def _extract_source(field: str, data: Any) -> _Source:
    """Resolve raw field object into a unified _Source."""
    if field == "photo":
        largest = _largest_photo_size(data)
        return _Source(
            type=field,
            file_id=largest["file_id"],
            file_size=largest.get("file_size"),
            source_file_name=None,
            mime_type=None,
            width=largest.get("width"),
            height=largest.get("height"),
            duration_sec=None,
            performer=None,
            title=None,
        )
    if field == "live_photo":
        largest = _largest_photo_size(data.get("photo") or [])
        return _Source(
            type=field,
            file_id=largest["file_id"],
            file_size=largest.get("file_size"),
            source_file_name=None,
            mime_type=None,
            width=largest.get("width"),
            height=largest.get("height"),
            duration_sec=None,
            performer=None,
            title=None,
        )
    if field == "video_note":
        length = data.get("length")
        duration = data.get("duration")
        return _Source(
            type=field,
            file_id=data["file_id"],
            file_size=data.get("file_size"),
            source_file_name=None,
            mime_type=None,
            width=length,
            height=length,
            duration_sec=float(duration) if duration is not None else None,
            performer=None,
            title=None,
        )
    duration = data.get("duration")
    return _Source(
        type=field,
        file_id=data["file_id"],
        file_size=data.get("file_size"),
        source_file_name=data.get("file_name"),
        mime_type=data.get("mime_type"),
        width=data.get("width"),
        height=data.get("height"),
        duration_sec=float(duration) if duration is not None else None,
        performer=data.get("performer") if field == "audio" else None,
        title=data.get("title") if field == "audio" else None,
    )


def is_valid_file_name(name: str) -> bool:
    """Check if filename is safe across Windows, Linux, iOS, and macOS simultaneously.

    Rejects:
    - Empty, '.', '..'
    - Trailing dots or spaces
    - Filenames exceeding 255 UTF-8 bytes or failing UTF-8 encoding
    - ASCII control characters (0x00–0x1F)
    - Characters / \\ : * ? " < > |
    - Windows reserved device names (CON, PRN, AUX, NUL, COM1-9, LPT1-9) matching stem
    """
    if not name or name in (".", ".."):
        return False
    if name[-1] in (".", " "):
        return False
    try:
        if len(name.encode("utf-8")) > _MAX_FILE_NAME_BYTES:
            return False
    except UnicodeEncodeError:
        return False
    if any(ord(char) < 32 or char in _UNSAFE_FILE_NAME_CHARS for char in name):
        return False
    stem = name.split(".", 1)[0]
    return stem.upper() not in _RESERVED_DEVICE_NAMES


def _resolve_file_name(source: _Source, attachment_id: int) -> str:
    """Use source filename if safe, else fallback to template."""
    if source.source_file_name and is_valid_file_name(source.source_file_name):
        return source.source_file_name
    return f"{attachment_id}_{source.type}.{_FALLBACK_EXT[source.type]}"


def download_attachment(
    message: dict[str, Any],
    client: TelegramClient,
    max_attachment_size_bytes: int,
    attachment_id: int = 1,
) -> AttachmentInfo | None:
    """Download single attachment from a Telegram message if present.

    Never raises on download or size errors: returns an AttachmentInfo with
    status="skipped" and error_reason set appropriately.
    """
    field = next((f for f in ATTACHMENT_FIELDS if f in message), None)
    if field is None:
        return None

    try:
        source = _extract_source(field, message[field])
    except NoSizeVariantError:
        return AttachmentInfo(
            attachment_id=attachment_id,
            type=field,
            file_name=None,
            status="skipped",
            error_reason="download_error",
            content=None,
            size_bytes=None,
            mime_type=None,
        )

    # 1. Early size check before network request
    if source.file_size is not None and source.file_size > max_attachment_size_bytes:
        return AttachmentInfo(
            attachment_id=attachment_id,
            type=source.type,
            file_name=None,
            status="skipped",
            error_reason="size_limit_exceeded",
            content=None,
            size_bytes=source.file_size,
            mime_type=source.mime_type,
            width=source.width,
            height=source.height,
            duration_sec=source.duration_sec,
        )

    # 2. Get file metadata from Bot API
    try:
        file_info = client.get_file(source.file_id)
    except TelegramAPIError:
        return AttachmentInfo(
            attachment_id=attachment_id,
            type=source.type,
            file_name=None,
            status="skipped",
            error_reason="unavailable_in_source",
            content=None,
            size_bytes=source.file_size,
            mime_type=source.mime_type,
        )
    except TelegramRetryExhaustedError:
        return AttachmentInfo(
            attachment_id=attachment_id,
            type=source.type,
            file_name=None,
            status="skipped",
            error_reason="download_error",
            content=None,
            size_bytes=source.file_size,
            mime_type=source.mime_type,
        )

    # 3. Post-getFile size check: unconfirmed size treated as exceeding limit
    file_size = file_info.get("file_size", source.file_size)
    if file_size is None or file_size > max_attachment_size_bytes:
        return AttachmentInfo(
            attachment_id=attachment_id,
            type=source.type,
            file_name=None,
            status="skipped",
            error_reason="size_limit_exceeded",
            content=None,
            size_bytes=file_size,
            mime_type=source.mime_type,
            width=source.width,
            height=source.height,
            duration_sec=source.duration_sec,
        )

    file_path = file_info.get("file_path")
    if not file_path:
        return AttachmentInfo(
            attachment_id=attachment_id,
            type=source.type,
            file_name=None,
            status="skipped",
            error_reason="unavailable_in_source",
            content=None,
            size_bytes=file_size,
            mime_type=source.mime_type,
        )

    # 4. Download file bytes
    try:
        content = client.download_file(file_path)
    except TelegramAPIError:
        return AttachmentInfo(
            attachment_id=attachment_id,
            type=source.type,
            file_name=None,
            status="skipped",
            error_reason="unavailable_in_source",
            content=None,
            size_bytes=file_size,
            mime_type=source.mime_type,
        )
    except TelegramRetryExhaustedError:
        return AttachmentInfo(
            attachment_id=attachment_id,
            type=source.type,
            file_name=None,
            status="skipped",
            error_reason="download_error",
            content=None,
            size_bytes=file_size,
            mime_type=source.mime_type,
        )

    file_name = _resolve_file_name(source, attachment_id)
    return AttachmentInfo(
        attachment_id=attachment_id,
        type=source.type,
        file_name=file_name,
        status="downloaded",
        error_reason=None,
        content=content,
        size_bytes=file_size,
        mime_type=source.mime_type,
        width=source.width,
        height=source.height,
        duration_sec=source.duration_sec,
    )
