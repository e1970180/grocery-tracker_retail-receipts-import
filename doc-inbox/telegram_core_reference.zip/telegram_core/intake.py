"""Intake classification: route a raw Telegram Update dict before any I/O starts.

Implements the 9 ranked rules of Telegram message intake:
1. Message / edited_message presence check (update without either is silently ignored)
2. Scope & Authorization gate (allowed_user_ids, private chat, message_id > 0)
3. Third-party modes filter (business_connection_id, guest_query_id)
4. System/service messages filter (55 known Telegram Bot API 10.3 infrastructure fields)
5. Forward origin validation: unknown forward_origin.type yields NO_BUNDLE with 🤔
6. Payload classification: Category 1 (text, photo, document, etc.) yields BUNDLE with 👍
7. Unsupported payload classification: Category 3 (sticker, poll, contact, etc.) yields NO_BUNDLE with 👎
8. Unrecognised/new Telegram Bot API field yields NO_BUNDLE with 🤔
9. Empty message (no text, caption, or recognized payload) yields NO_BUNDLE with 👎
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto
from typing import Any, Literal


class Outcome(Enum):
    """Classification outcome."""

    BUNDLE = auto()
    NO_BUNDLE = auto()
    SILENT = auto()


@dataclass(frozen=True, slots=True)
class IntakeResult:
    """Classification result. `reaction` is None if and only if `outcome` is SILENT."""

    outcome: Outcome
    reaction: Literal["👍", "👎", "🤔"] | None


_SILENT_RESULT = IntakeResult(Outcome.SILENT, None)

_GATE_FIELDS = frozenset({"message_id", "chat", "from"})
_THIRD_PARTY_FIELDS = frozenset({"business_connection_id", "guest_query_id"})

# Known forward origin types in Telegram Bot API (user, hidden_user, chat, channel)
_KNOWN_FORWARD_ORIGIN_TYPES = frozenset({"user", "hidden_user", "chat", "channel"})

# Category 1: Valid payload triggering message intake/processing
_CATEGORY_1_FIELDS = frozenset(
    {
        "text",
        "photo",
        "video",
        "document",
        "audio",
        "voice",
        "video_note",
        "animation",
        "live_photo",
    }
)

# Category 3: Unsupported user payload with explicit negative reaction
_CATEGORY_3_FIELDS = frozenset(
    {
        "sticker",
        "contact",
        "dice",
        "game",
        "poll",
        "checklist",
        "location",
        "venue",
        "invoice",
        "giveaway",
        "giveaway_winners",
        "story",
        "paid_media",
        "rich_message",
    }
)

# Category 2: 55 known Telegram Bot API 10.3 service/infrastructure message fields (silently ignored)
_CATEGORY_2_FIELDS = frozenset(
    {
        "new_chat_members",
        "left_chat_member",
        "chat_owner_left",
        "chat_owner_changed",
        "new_chat_title",
        "new_chat_photo",
        "delete_chat_photo",
        "group_chat_created",
        "supergroup_chat_created",
        "channel_chat_created",
        "message_auto_delete_timer_changed",
        "migrate_to_chat_id",
        "migrate_from_chat_id",
        "pinned_message",
        "successful_payment",
        "refunded_payment",
        "users_shared",
        "chat_shared",
        "gift",
        "unique_gift",
        "gift_upgrade_sent",
        "forum_topic_created",
        "forum_topic_edited",
        "forum_topic_closed",
        "forum_topic_reopened",
        "general_forum_topic_hidden",
        "general_forum_topic_unhidden",
        "giveaway_created",
        "giveaway_completed",
        "video_chat_scheduled",
        "video_chat_started",
        "video_chat_ended",
        "video_chat_participants_invited",
        "community_chat_added",
        "community_chat_joined",
        "community_chat_removed",
        "web_app_data",
        "passport_data",
        "write_access_allowed",
        "boost_added",
        "chat_background_set",
        "proximity_alert_triggered",
        "checklist_tasks_done",
        "checklist_tasks_added",
        "direct_message_price_changed",
        "paid_message_price_changed",
        "suggested_post_approved",
        "suggested_post_approval_failed",
        "suggested_post_declined",
        "suggested_post_paid",
        "suggested_post_refunded",
        "connected_website",
        "managed_bot_created",
        "poll_option_added",
        "poll_option_deleted",
    }
)

_METADATA_FIELDS = frozenset(
    {
        "message_thread_id",
        "ephemeral_message_id",
        "date",
        "sender_chat",
        "sender_boost_count",
        "sender_business_bot",
        "sender_tag",
        "receiver_user",
        "via_bot",
        "guest_bot_caller_user",
        "guest_bot_caller_chat",
        "author_signature",
        "forward_origin",
        "is_automatic_forward",
        "reply_to_message",
        "external_reply",
        "quote",
        "reply_to_story",
        "reply_to_checklist_task_id",
        "reply_to_poll_option_id",
        "edit_date",
        "has_protected_content",
        "is_from_offline",
        "is_topic_message",
        "has_media_spoiler",
        "media_group_id",
        "reply_markup",
        "entities",
        "caption_entities",
        "caption",
        "show_caption_above_media",
        "link_preview_options",
        "is_paid_post",
        "paid_star_count",
        "effect_id",
        "direct_messages_topic",
    }
)

_KNOWN_FIELDS = (
    _GATE_FIELDS
    | _THIRD_PARTY_FIELDS
    | _CATEGORY_1_FIELDS
    | _CATEGORY_2_FIELDS
    | _CATEGORY_3_FIELDS
    | _METADATA_FIELDS
)


def classify_update(
    update: dict[str, Any], allowed_user_ids: list[int]
) -> IntakeResult:
    """Classify one raw Update dict per the 9 ranked rules.

    Pure function: no network, filesystem, or logging. Never raises.
    """
    message = select_message(update)
    if message is None:
        return _SILENT_RESULT
    if not _authorized(message, allowed_user_ids):
        return _SILENT_RESULT
    if message.keys() & _THIRD_PARTY_FIELDS:
        return _SILENT_RESULT
    if message.keys() & _CATEGORY_2_FIELDS:
        return _SILENT_RESULT

    forward_origin = message.get("forward_origin")
    if (
        isinstance(forward_origin, dict)
        and forward_origin.get("type") not in _KNOWN_FORWARD_ORIGIN_TYPES
    ):
        return IntakeResult(Outcome.NO_BUNDLE, "🤔")

    if message.keys() & _CATEGORY_1_FIELDS:
        return IntakeResult(Outcome.BUNDLE, "👍")
    if message.keys() & _CATEGORY_3_FIELDS:
        return IntakeResult(Outcome.NO_BUNDLE, "👎")
    if message.keys() - _KNOWN_FIELDS:
        return IntakeResult(Outcome.NO_BUNDLE, "🤔")
    return IntakeResult(Outcome.NO_BUNDLE, "👎")


def select_message(update: dict[str, Any]) -> dict[str, Any] | None:
    """Extract `message` or `edited_message` payload dict."""
    if not isinstance(update, dict):
        return None
    if "message" in update:
        candidate = update["message"]
    elif "edited_message" in update:
        candidate = update["edited_message"]
    else:
        return None
    return candidate if isinstance(candidate, dict) else None


def _authorized(message: dict[str, Any], allowed_user_ids: list[int]) -> bool:
    """Authorize sender, verify private chat, and filter phantom/scheduled messages."""
    sender = message.get("from")
    sender_id = sender.get("id") if isinstance(sender, dict) else None
    chat = message.get("chat")
    chat_type = chat.get("type") if isinstance(chat, dict) else None
    message_id = message.get("message_id")
    return (
        sender_id in allowed_user_ids
        and chat_type == "private"
        and isinstance(message_id, int)
        and message_id > 0
    )
