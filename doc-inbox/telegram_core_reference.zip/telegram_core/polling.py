"""Long polling ingestion loop with durable offset tracking and isolated reactions.

Guarantees:
1. Offset durability: Writes to a .tmp file, flushes, fsyncs to disk,
   then atomic os.replace. Eliminates 0-byte file truncation on abrupt process kill.
2. Error resilience: Catches and swallows OSError on offset write without killing daemon.
   Suppresses secondary errors during temporary file cleanup.
3. Reaction isolation: Reaction failures are logged with token redaction and swallowed,
   so a reaction error never breaks message processing.
"""

from __future__ import annotations

import contextlib
import logging
import os
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

from telegram_core.attachments import AttachmentInfo, download_attachment
from telegram_core.client import TelegramClient, _redact
from telegram_core.intake import Outcome, classify_update, select_message

logger = logging.getLogger(__name__)

_DEFAULT_POLL_TIMEOUT_SECONDS = 30
_ALLOWED_UPDATES = ["message", "edited_message"]
_ERROR_BACKOFF_SECONDS = 5.0


def read_offset(path: Path) -> int | None:
    """Read the next update offset from disk, or None if absent/empty/corrupted."""
    try:
        content = path.read_text(encoding="utf-8").strip()
    except (FileNotFoundError, OSError, UnicodeDecodeError):
        return None
    if not content:
        return None
    try:
        return int(content)
    except ValueError:
        return None


def write_offset(path: Path, offset: int) -> None:
    """Durably persist offset using temp file + fsync + atomic replace.

    Never raises: logs and swallows OSError so disk issues do not kill the daemon.
    """
    tmp_path = path.with_suffix(".tmp")
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(tmp_path, "w", encoding="utf-8") as f:
            f.write(str(offset))
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, path)
    except OSError as exc:
        logger.error("write offset %s to %s failed: %s", offset, path, exc)
        with contextlib.suppress(OSError):
            tmp_path.unlink(missing_ok=True)


def send_reaction(
    client: TelegramClient,
    chat_id: int,
    message_id: int,
    reaction: str,
    token: str,
) -> None:
    """Send emoji reaction; never raises -- errors are redacted and swallowed."""
    try:
        client.set_message_reaction(chat_id, message_id, reaction)
    except Exception as exc:
        logger.error(
            "set_message_reaction(chat_id=%s, message_id=%s, reaction=%s) failed: %s",
            chat_id,
            message_id,
            reaction,
            _redact(str(exc), token),
        )


MessageHandler = Callable[[dict[str, Any], AttachmentInfo | None], bool]


def process_single_update(
    update: dict[str, Any],
    client: TelegramClient,
    allowed_user_ids: list[int],
    max_attachment_size_bytes: int,
    bot_token_value: str,
    on_message: MessageHandler | None = None,
) -> None:
    """Process a single Telegram update to completion."""
    message = select_message(update)
    result = classify_update(update, allowed_user_ids)

    if result.outcome == Outcome.SILENT:
        return

    assert isinstance(message, dict)
    chat_id = message["chat"]["id"]
    message_id = message["message_id"]

    if result.outcome == Outcome.NO_BUNDLE:
        if result.reaction:
            send_reaction(client, chat_id, message_id, result.reaction, bot_token_value)
        return

    # Outcome.BUNDLE: download attachment if present
    attachment = download_attachment(
        message, client, max_attachment_size_bytes
    )

    success = True
    if on_message is not None:
        try:
            success = on_message(message, attachment)
        except Exception as exc:
            logger.error("on_message handler failed: %s", _redact(str(exc), bot_token_value))
            success = False

    # Default reaction logic: thumbs up on success, broken heart on error
    reaction = "👍" if success else "💔"
    send_reaction(client, chat_id, message_id, reaction, bot_token_value)


def run_polling_loop(
    client: TelegramClient,
    allowed_user_ids: list[int],
    offset_file: Path,
    max_attachment_size_bytes: int,
    bot_token_value: str,
    *,
    poll_timeout: int = _DEFAULT_POLL_TIMEOUT_SECONDS,
    on_message: MessageHandler | None = None,
    stop_predicate: Callable[[], bool] | None = None,
) -> None:
    """Run continuous long polling loop."""
    offset = read_offset(offset_file)
    logger.info("Starting Telegram polling from offset %s", offset)

    while True:
        if stop_predicate and stop_predicate():
            break

        try:
            updates = client.get_updates(
                offset=offset,
                timeout=poll_timeout,
                allowed_updates=_ALLOWED_UPDATES,
            )
        except Exception as exc:
            logger.error(
                "get_updates failed, retrying in %.1fs: %s",
                _ERROR_BACKOFF_SECONDS,
                _redact(str(exc), bot_token_value),
            )
            time.sleep(_ERROR_BACKOFF_SECONDS)
            continue

        for update in updates:
            update_id = update["update_id"]
            try:
                process_single_update(
                    update,
                    client,
                    allowed_user_ids,
                    max_attachment_size_bytes,
                    bot_token_value,
                    on_message,
                )
            except Exception as exc:
                logger.error(
                    "Unexpected error processing update %s: %s",
                    update_id,
                    _redact(str(exc), bot_token_value),
                )

            offset = update_id + 1
            write_offset(offset_file, offset)
